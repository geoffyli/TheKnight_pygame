<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="stringstar_tileset" tilewidth="16" tileheight="16" tilecount="198" columns="18">
 <image source="../tilesets/stringstar_tileset.png" width="288" height="176"/>
</tileset>
