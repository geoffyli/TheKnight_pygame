<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="cliff_tileset" tilewidth="16" tileheight="16" tilecount="1160" columns="58">
 <image source="../tilesets/cliff_tileset.png" width="928" height="320"/>
</tileset>
